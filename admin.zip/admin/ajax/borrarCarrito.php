<?php
    setcookie("productos","");
    echo json_encode(array());
?>