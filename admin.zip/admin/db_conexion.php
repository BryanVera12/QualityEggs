<?php
    $host="aatxk0r7oa9wj5.cbt4qtyzvii2.us-east-1.rds.amazonaws.com";
    $user="AlexAdmin";
    $pass="12345678";
    $db="ecommerce";
    $port="3306";
    $socket="";
?>
