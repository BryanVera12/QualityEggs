<div class="content-wrapper">
    <table class="table table-striped table-inverse" id="tablaCarrito" >
        <thead class="thead-inverse">
            <tr>
                <th>Imagen</th>
                <th>Nombre</th>
                <th>Cantidad</th>
                <th>Precio</th>
                <th>Total</th>
                <th></th>
            </tr>
        </thead>
        <tbody>
        </tbody>
    </table>
    <a class="btn btn-warning" href="panel_2.php?modulo=productos_2" role="button">Ir a productos</a>
    <a class="btn btn-primary float-right" href="panel_2.php?modulo=envio" role="button">Ir a datos de envio</a>
</div>